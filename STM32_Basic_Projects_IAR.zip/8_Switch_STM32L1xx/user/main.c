#include "stm32l1xx.h"

int main()
{
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOE, ENABLE);
  
  
}