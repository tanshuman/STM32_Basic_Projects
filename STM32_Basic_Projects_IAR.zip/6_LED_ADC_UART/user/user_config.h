#include "stm32f4xx.h"

void RCC_Configuration(void);
void GPIO_Configuration(void);
void ADC_Configuration(void);
void USART_Configuration(void);
void RTC_Configuration(void);


